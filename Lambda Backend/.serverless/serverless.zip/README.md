To run :

serverless deploy